/**
 * 
 */
/**
 * 
 */
module TripNevigator {
	requires java.desktop;
	requires java.sql;
}